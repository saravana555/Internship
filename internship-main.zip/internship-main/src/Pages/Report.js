function Report() {
    return <>
        Report
    </>
}

export default Report